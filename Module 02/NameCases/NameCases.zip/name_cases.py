# Assigning a person's name to a variable
person_name = "john doe"

# Printing the name in lowercase
print("Lowercase:", person_name.lower())

# Printing the name in uppercase
print("Uppercase:", person_name.upper())

# Printing the name in title case
print("Title Case:", person_name.title())
