# Define the quote and its author
quote = "If you want to find the secrets of the universe, think in terms of energy, frequency, and vibration."
author = "Nikola Tesla"

# Print the quote with the author's name
print(author + " once said, \"" + quote + "\"")
