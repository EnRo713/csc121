# Assigning a message to a variable and printing it
message = "Hello, world!"
print(message)

# Changing the value of the variable and printing the new message
message = "This is a new message."
print(message)
