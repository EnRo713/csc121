# Addition
print("Addition:")
print(5 + 3)

# Subtraction
print("\nSubtraction:")
print(10 - 2)

# Multiplication
print("\nMultiplication:")
print(4 * 2)

# Division
print("\nDivision:")
print(16 / 2)
