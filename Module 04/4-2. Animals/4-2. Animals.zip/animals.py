# Define a list of animals with a unique common characteristic
animals = ["Platypus", "Echidna", "Spiny anteater"]

# Print the name of each animal using a for loop
print("Animals:")
for animal in animals:
    print(animal)

# Print a statement about each animal
for animal in animals:
    print("The", animal.lower(), "is a monotreme.")

# Print a statement about what these animals have in common
print("All of these animals lay eggs and produce milk.")
